/* Honest Penny v2 — PennyAuto: automatic coupon testing at checkout.
 *
 * What it does (ONLY after the user explicitly clicks "Test my codes"):
 *  - Detects checkout/cart pages (URL pattern OR a visible promo field).
 *  - Finds the retailer's promo-code field (per-store overrides, else a
 *    generic heuristic that matches promo/coupon/discount/voucher inputs).
 *  - Tries each cached code one at a time: fills the field, clicks the
 *    retailer's own Apply button, waits, and reads the cart total.
 *  - Keeps the code that produced the lowest total and re-applies it.
 *  - Records the savings so the popup can show a lifetime total.
 *
 * What it NEVER does:
 *  - Never runs without an explicit user click. No auto-run on page load.
 *  - Never submits an order, never touches payment/shipping/login fields.
 *  - Never sends any data anywhere. Everything stays in the page.
 *
 * Exposes window.PennyAuto = { isCheckoutPage, findPromoField, testCodes }.
 * Remote per-store tuning lives in data/extension-config.json (fetched by
 * the background worker into chrome.storage.local as cc_ext_config), so
 * retailers can be tuned without shipping a new extension version.
 */
/* global CC_EXT_CONFIG */
(function () {
  "use strict";

  var DEFAULTS = {
    checkout_url_pattern: "checkout|check-out|/cart|/basket|/bag|/payment|order-review|order_summary|shipping",
    promo_attrs: ["promo", "coupon", "discount", "voucher", "promocode", "couponcode", "discountcode", "giftcard", "gift-card", "rewards-code"],
    exclude_attrs: ["email", "e-mail", "password", "passwd", "search", "username", "user-name", "phone", "tel", "address", "login", "signin", "sign-in", "card-number", "cvv", "zip"],
    apply_button_text: "apply|redeem|^add$|use code",
    total_labels: ["order total", "grand total", "estimated total", "total amount", "amount due", "order summary", "cart total", "subtotal"],
    error_text: "invalid|expired|not valid|does not apply|doesn't apply|cannot be applied|can't be applied|already applied|not recognized|incorrect|please enter|try again|not eligible|minimum",
    max_codes: 12,
    wait_after_apply_ms: 3200,
    delay_between_codes_ms: 2200
  };

  function cfg() {
    var remote = (typeof CC_EXT_CONFIG !== "undefined" && CC_EXT_CONFIG) || {};
    var d = {};
    var k;
    for (k in DEFAULTS) d[k] = DEFAULTS[k];
    if (remote.defaults) for (k in remote.defaults) d[k] = remote.defaults[k];
    return { d: d, stores: remote.stores || {} };
  }

  function storeCfg(slug) {
    var c = cfg();
    return c.stores[slug] || {};
  }

  /* ---------------- checkout detection ---------------- */

  function isCheckoutPage(slug) {
    var c = cfg();
    var sc = storeCfg(slug);
    var pattern = sc.checkout_url || c.d.checkout_url_pattern;
    try {
      if (new RegExp(pattern, "i").test(location.href)) return true;
    } catch (e) { /* bad pattern: fall through to field sniffing */ }
    return !!findPromoField(slug);
  }

  /* ---------------- element helpers ---------------- */

  function visible(el) {
    if (!el || el.disabled) return false;
    if (el.type === "hidden") return false;
    try {
      var r = el.getBoundingClientRect();
      if (r.width < 4 || r.height < 4) return false;
    } catch (e) { return false; }
    var style;
    try { style = window.getComputedStyle(el); } catch (e) { return true; }
    return style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
  }

  function attrBlob(el) {
    return ((el.id || "") + " " + (el.name || "") + " " + (el.placeholder || "") + " " +
      (el.getAttribute("aria-label") || "") + " " + (el.className || "")).toLowerCase();
  }

  function trySelectors(selectors) {
    for (var i = 0; i < selectors.length; i++) {
      var els;
      try { els = document.querySelectorAll(selectors[i]); } catch (e) { continue; }
      for (var j = 0; j < els.length; j++) {
        if (visible(els[j])) return els[j];
      }
    }
    return null;
  }

  /* ---------------- promo field ---------------- */

  function findPromoField(slug) {
    var sc = storeCfg(slug);
    if (sc.promo_selectors && sc.promo_selectors.length) {
      var hit = trySelectors(sc.promo_selectors);
      if (hit) return hit;
    }
    var c = cfg().d;
    var inputs = document.querySelectorAll('input[type="text"], input[type="search"], input:not([type])');
    for (var i = 0; i < inputs.length; i++) {
      var el = inputs[i];
      if (!visible(el)) continue;
      var blob = attrBlob(el);
      var okAttr = false, k;
      for (k = 0; k < c.promo_attrs.length; k++) {
        if (blob.indexOf(c.promo_attrs[k]) !== -1) { okAttr = true; break; }
      }
      if (!okAttr) continue;
      var bad = false;
      for (k = 0; k < c.exclude_attrs.length; k++) {
        if (blob.indexOf(c.exclude_attrs[k]) !== -1) { bad = true; break; }
      }
      if (bad) continue;
      /* Skip fields inside a login form (a form containing a password input). */
      var form = el.form;
      if (form && form.querySelector('input[type="password"]')) continue;
      return el;
    }
    return null;
  }

  /* ---------------- apply button ---------------- */

  function buttonTextMatch(el, pattern) {
    var t = (el.textContent || el.value || "").trim().toLowerCase();
    if (!t) return false;
    try { return new RegExp(pattern, "i").test(t); } catch (e) { return false; }
  }

  function findApplyButton(field, slug) {
    var sc = storeCfg(slug);
    var c = cfg().d;
    if (sc.apply_selectors && sc.apply_selectors.length) {
      var hit = trySelectors(sc.apply_selectors);
      if (hit) return hit;
    }
    var scope = field.form || field.parentElement;
    if (scope) {
      var btns = scope.querySelectorAll('button, input[type="submit"], input[type="button"], [role="button"]');
      for (var i = 0; i < btns.length; i++) {
        if (visible(btns[i]) && buttonTextMatch(btns[i], c.apply_button_text)) return btns[i];
      }
    }
    /* Widen: walk up a few levels looking for an apply-ish button. */
    var node = field.parentElement, depth = 0;
    while (node && depth < 4) {
      var cand = node.querySelectorAll('button, input[type="submit"], input[type="button"]');
      for (var j = 0; j < cand.length; j++) {
        if (visible(cand[j]) && buttonTextMatch(cand[j], c.apply_button_text)) return cand[j];
      }
      node = node.parentElement; depth++;
    }
    return null;
  }

  /* ---------------- cart total ---------------- */

  function parseMoney(text) {
    var m = /\$\s?([\d,]+\.\d{2})/.exec(text || "");
    if (!m) return null;
    var v = parseFloat(m[1].replace(/,/g, ""));
    return isFinite(v) ? v : null;
  }

  /* Cache the element that held the total: totals update in place on most
     checkout pages, so subsequent polls can skip the full DOM scan. */
  var totalElCache = null;

  function readTotal(slug) {
    var sc = storeCfg(slug);
    if (sc.total_selectors && sc.total_selectors.length) {
      var hit = trySelectors(sc.total_selectors);
      if (hit) {
        var v0 = parseMoney(hit.textContent);
        if (v0 !== null) { totalElCache = hit; return v0; }
      }
    }
    if (totalElCache && totalElCache.isConnected) {
      var vc = parseMoney(totalElCache.textContent);
      if (vc !== null) return vc;
      totalElCache = null;
    }
    var c = cfg().d;
    var best = null, bestScore = -1, bestEl = null, bestLen = Infinity;
    var all = document.querySelectorAll("body *");
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      /* Never read money out of script/style/template source. */
      var tag = el.tagName;
      if (tag === "SCRIPT" || tag === "STYLE" || tag === "NOSCRIPT" || tag === "TEMPLATE") continue;
      if (el.children.length > 0) continue; /* leaf nodes only */
      var text = (el.textContent || "").trim();
      if (text.length > 40) continue;
      var money = parseMoney(text);
      if (money === null) continue;
      var score = 0;
      var node = el, depth = 0, ctx = "";
      while (node && depth < 4) {
        ctx += " " + ((node.textContent || "").slice(0, 120)).toLowerCase();
        node = node.parentElement; depth++;
      }
      for (var k = 0; k < c.total_labels.length; k++) {
        if (ctx.indexOf(c.total_labels[k]) !== -1) { score += 10 - k; break; }
      }
      score -= depth;
      /* Tie-break: prefer the shorter (more specific) money text, e.g. a
         bare "$80.00" total over a static "Subtotal (2 items): $100.00" line
         that happens to score the same. */
      if (score > bestScore || (score === bestScore && text.length < bestLen)) {
        bestScore = score; best = money; bestEl = el; bestLen = text.length;
      }
    }
    if (bestEl) totalElCache = bestEl;
    return best;
  }

  /* Visible text under a root, skipping script/style/template source: an
     inline <script> can literally contain the words "invalid"/"expired"
     (e.g. its own error strings), which must never count as the page
     showing the shopper an error. Same for money scanning. */
  function visibleText(root) {
    var parts = [];
    var walker;
    try {
      walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode: function (n) {
          var p = n.parentElement;
          if (!p) return NodeFilter.FILTER_REJECT;
          var tag = p.tagName;
          if (tag === "SCRIPT" || tag === "STYLE" || tag === "NOSCRIPT" ||
              tag === "TEMPLATE" || tag === "TEXTAREA") return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        }
      });
    } catch (e) { return (root.textContent || ""); }
    var n;
    while ((n = walker.nextNode())) parts.push(n.nodeValue);
    return parts.join(" ");
  }

  function pageShowsError(field) {
    var c = cfg().d;
    var scope = field.form || field.parentElement;
    var root = scope;
    var node = field.parentElement, depth = 0;
    while (node && depth < 3) { root = node; node = node.parentElement; depth++; }
    var blob = "";
    try { blob = visibleText(root || document.body).toLowerCase(); } catch (e) {}
    try { return new RegExp(c.error_text, "i").test(blob); } catch (e) { return false; }
  }

  /* ---------------- value setting (framework-safe) ---------------- */

  function setFieldValue(field, value) {
    try { field.focus(); } catch (e) {}
    try {
      var proto = field.tagName === "TEXTAREA"
        ? window.HTMLTextAreaElement.prototype
        : window.HTMLInputElement.prototype;
      var setter = Object.getOwnPropertyDescriptor(proto, "value").set;
      setter.call(field, value);
    } catch (e) {
      try { field.value = value; } catch (e2) {}
    }
    field.dispatchEvent(new Event("input", { bubbles: true }));
    field.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function sleep(ms) {
    return new Promise(function (res) { setTimeout(res, ms); });
  }

  /* ---------------- the test loop ---------------- */

  function testCodes(slug, codes, hooks) {
    hooks = hooks || {};
    var c = cfg().d;
    var sc = storeCfg(slug);
    var maxCodes = sc.max_codes || c.max_codes;
    /* The user's own options-page choice wins over remote config. */
    try {
      if (typeof CC_USER_MAX_CODES !== "undefined" && CC_USER_MAX_CODES > 0) {
        maxCodes = CC_USER_MAX_CODES;
      }
    } catch (e) {}
    var waitMs = sc.wait_after_apply_ms || c.wait_after_apply_ms;
    var gapMs = sc.delay_between_codes_ms || c.delay_between_codes_ms;

    var cancelled = false;
    var navigated = false;
    window.addEventListener("pagehide", function () { navigated = true; }, { once: true });

    function progress(info) {
      try { if (hooks.onProgress) hooks.onProgress(info); } catch (e) {}
    }
    function done(result) {
      try { if (hooks.onDone) hooks.onDone(result); } catch (e) {}
    }

    function run() {
      var field = findPromoField(slug);
      if (!field) {
        done({ ok: false, reason: "no-field", tried: 0 });
        return;
      }
      var applyBtn = findApplyButton(field, slug);
      var startTotal = readTotal(slug);
      var queue = codes.filter(function (x) { return x && x.code; }).slice(0, maxCodes);

      if (!queue.length) {
        done({ ok: false, reason: "no-codes", tried: 0 });
        return;
      }

      var best = null; /* {code, total} */
      var i = 0;

      function next() {
        if (cancelled) { finish({ ok: false, reason: "cancelled", tried: i }); return; }
        if (navigated) { finish({ ok: false, reason: "navigated", tried: i }); return; }
        if (i >= queue.length) { finish(null); return; }
        var coupon = queue[i];
        progress({ done: i, total: queue.length, code: coupon.code, status: "testing" });
        try {
          setFieldValue(field, "");
          setFieldValue(field, coupon.code);
          if (applyBtn && visible(applyBtn)) {
            applyBtn.click();
          } else {
            field.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
          }
        } catch (e) { /* fall through to wait */ }

        var polls = 0, maxPolls = Math.ceil(waitMs / 400);
        var baseline = (best && best.total !== null) ? best.total : startTotal;
        (function poll() {
          if (cancelled || navigated) { finish({ ok: false, reason: cancelled ? "cancelled" : "navigated", tried: i + 1 }); return; }
          var total = readTotal(slug);
          var err = pageShowsError(field);
          var improved = (total !== null && baseline !== null && total < baseline - 0.005);
          if (improved || err || ++polls >= maxPolls) {
            if (improved && (best === null || total < best.total)) {
              best = { code: coupon.code, total: total, title: coupon.title };
            }
            progress({ done: i + 1, total: queue.length, code: coupon.code, status: improved ? "worked" : (err ? "rejected" : "no-change") });
            i++;
            setTimeout(next, gapMs);
          } else {
            setTimeout(poll, 400);
          }
        })();
      }

      function finish(early) {
        if (early) { done(early); return; }
        if (best) {
          /* Re-apply the winner so the shopper keeps the best price. */
          try {
            setFieldValue(field, "");
            setFieldValue(field, best.code);
            if (applyBtn && visible(applyBtn)) applyBtn.click();
          } catch (e) {}
          setTimeout(function () {
            var finalTotal = readTotal(slug);
            var saved = (startTotal !== null && finalTotal !== null)
              ? Math.max(0, startTotal - finalTotal) : 0;
            recordSavings(slug, best.code, saved);
            done({ ok: true, saved: saved, code: best.code, title: best.title, tried: queue.length, startTotal: startTotal, finalTotal: finalTotal });
          }, Math.min(waitMs, 2500));
        } else {
          try { setFieldValue(field, ""); } catch (e) {}
          done({ ok: false, reason: "none-worked", tried: queue.length });
        }
      }

      next();
    }

    /* Kick off async so the caller can wire up listeners first. */
    setTimeout(run, 50);

    return { cancel: function () { cancelled = true; } };
  }

  function recordSavings(slug, code, amount) {
    if (!(amount > 0)) return;
    try {
      chrome.storage.local.get(["cc_saved_total", "cc_saved_count"], function (res) {
        var total = parseFloat(res.cc_saved_total || 0) + amount;
        var count = parseInt(res.cc_saved_count || 0, 10) + 1;
        chrome.storage.local.set({
          cc_saved_total: Math.round(total * 100) / 100,
          cc_saved_count: count,
          cc_last_save: { amount: Math.round(amount * 100) / 100, code: code, store: slug, at: Date.now() }
        });
      });
    } catch (e) {}
  }

  window.PennyAuto = {
    isCheckoutPage: isCheckoutPage,
    findPromoField: findPromoField,
    testCodes: testCodes,
    readTotal: readTotal
  };
})();
