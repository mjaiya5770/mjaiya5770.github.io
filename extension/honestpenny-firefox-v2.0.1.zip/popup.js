/* Honest Penny v2 popup logic.
 * Reads cached coupons from chrome.storage.local (written by background.js).
 * Codes are revealed only on click; no code is sent anywhere.
 * The "Test my codes" button asks the content script to auto-try codes at
 * checkout — only ever after the user clicks it.
 */
/* global CC_SITE_URL, CC_STORES */
(function () {
  "use strict";

  var listEl = document.getElementById("pop-list");
  var emptyEl = document.getElementById("pop-empty");
  var noStoreEl = document.getElementById("pop-nostore");
  var storeEl = document.getElementById("pop-store");
  var countEl = document.getElementById("pop-count");
  var siteLink = document.getElementById("pop-site");
  var shopLink = document.getElementById("pop-shop");
  var shopDot = document.getElementById("pop-shop-dot");
  var optionsLink = document.getElementById("pop-options");
  var savingsEl = document.getElementById("pop-savings");
  var savedAmtEl = document.getElementById("pop-saved-amt");
  var testBox = document.getElementById("pop-test");
  var testSub = document.getElementById("pop-test-sub");
  var testIdle = document.getElementById("pop-test-idle");
  var testBtn = document.getElementById("pop-test-btn");
  var testProgress = document.getElementById("pop-test-progress");
  var testBar = document.getElementById("pop-test-bar");
  var testMsg = document.getElementById("pop-test-msg");
  var testCancel = document.getElementById("pop-test-cancel");
  var testResult = document.getElementById("pop-test-result");
  var SITE = (typeof CC_SITE_URL !== "undefined" ? CC_SITE_URL : "https://honest-penny.vercel.app");

  siteLink.href = SITE + "/";
  optionsLink.addEventListener("click", function (e) {
    e.preventDefault();
    try { chrome.runtime.openOptionsPage(); } catch (err) {}
  });

  function storeForHost(host) {
    host = (host || "").toLowerCase();
    for (var i = 0; i < (CC_STORES || []).length; i++) {
      var d = CC_STORES[i].domain;
      if (host === d || host.slice(-d.length - 1) === "." + d) return CC_STORES[i];
    }
    return null;
  }

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  // Mirror of the site's exact-timestamp verification proof:
  // "✓ Tested today at 9:41 AM PT" when we have today's time, else a
  // truthful relative label. Pacific "today" via Intl.
  function verifiedLabel(c) {
    var vd = c.verified_date;
    if (!vd) return "";
    var today;
    try {
      today = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Los_Angeles" }).format(new Date());
    } catch (e) {
      today = new Date().toISOString().slice(0, 10);
    }
    if (vd === today && c.verified_time) {
      var m = /^(\d{1,2}):(\d{2})$/.exec(c.verified_time);
      if (m) {
        var h = parseInt(m[1], 10), ap = h >= 12 ? "PM" : "AM", h12 = h % 12;
        if (h12 === 0) h12 = 12;
        return "\u2713 Tested today at " + h12 + ":" + m[2] + " " + ap + " PT";
      }
      return "\u2713 Verified today";
    }
    if (vd === today) return "\u2713 Verified today";
    var d = new Date(vd + "T12:00:00"), t = new Date(today + "T12:00:00");
    var days = Math.round((t - d) / 86400000);
    if (days === 1) return "\u2713 yesterday";
    if (days > 1 && days < 7) return "\u2713 " + days + " days ago";
    return "\u2713 " + d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  }

  /* Resolve a per-store shop URL. Affiliate entries may be templates with
     {url} (the store's own URL, encoded) and {id} (tracking id) — the same
     format the site uses. Only ever opened on explicit user clicks, never
     injected into the user's own navigation. */
  function resolveShopUrl(tpl, storeUrl, slug) {
    if (tpl) {
      return tpl.split("{url}").join(encodeURIComponent(storeUrl || ""))
                .split("{id}").join("ext-" + slug);
    }
    return storeUrl || "";
  }

  function sendToTab(msg, cb) {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      if (!tabs || !tabs[0] || !tabs[0].id) { if (cb) cb(null); return; }
      try {
        chrome.tabs.sendMessage(tabs[0].id, msg, function (resp) {
          if (chrome.runtime.lastError) { if (cb) cb(null); return; }
          if (cb) cb(resp || null);
        });
      } catch (e) { if (cb) cb(null); }
    });
  }

  /* ---------------- savings pill ---------------- */

  chrome.storage.local.get(["cc_saved_total", "cc_saved_count"], function (res) {
    var total = parseFloat(res.cc_saved_total || 0);
    if (total > 0) {
      savedAmtEl.textContent = "$" + total.toFixed(2);
      savingsEl.hidden = false;
    }
  });

  /* ---------------- auto-test UI ---------------- */

  var activeTabId = null;

  function showResult(text, good) {
    testResult.hidden = false;
    testResult.textContent = text;
    testResult.className = "result " + (good ? "good" : "flat");
  }

  chrome.runtime.onMessage.addListener(function (msg) {
    if (!msg) return;
    if (msg.type === "cc-autotest-progress") {
      testIdle.hidden = true;
      testProgress.hidden = false;
      testResult.hidden = true;
      testBar.style.width = Math.round((msg.done / Math.max(1, msg.total)) * 100) + "%";
      var label = msg.status === "worked" ? "worked!" : (msg.status === "rejected" ? "didn't take" : "trying…");
      testMsg.textContent = "Code " + (msg.done + (msg.status === "testing" ? 1 : 0)) + " of " + msg.total + ": " + msg.code + " — " + label;
    } else if (msg.type === "cc-autotest-done") {
      testProgress.hidden = true;
      testIdle.hidden = false;
      testBar.style.width = "0%";
      if (msg.ok && msg.saved > 0) {
        showResult("🎉 Penny saved you $" + Number(msg.saved).toFixed(2) + " with " + msg.code + "!", true);
      } else if (msg.ok) {
        showResult("Best code applied: " + msg.code + ". Penny kept your lowest total.", true);
      } else if (msg.reason === "no-field") {
        showResult("Penny couldn't find the promo box here — try the cart or checkout page.", false);
      } else if (msg.reason === "cancelled" || msg.reason === "navigated") {
        testResult.hidden = true;
      } else {
        showResult("None of the codes worked this time. Penny will keep hunting.", false);
      }
      /* refresh the savings pill */
      chrome.storage.local.get(["cc_saved_total"], function (res) {
        var total = parseFloat(res.cc_saved_total || 0);
        if (total > 0) {
          savedAmtEl.textContent = "$" + total.toFixed(2);
          savingsEl.hidden = false;
        }
      });
    }
  });

  testBtn.addEventListener("click", function () {
    testResult.hidden = true;
    testIdle.hidden = true;
    testProgress.hidden = false;
    testBar.style.width = "0%";
    testMsg.textContent = "Penny's warming up…";
    sendToTab({ type: "cc-autotest-start" }, function () {});
  });

  testCancel.addEventListener("click", function () {
    sendToTab({ type: "cc-autotest-cancel" }, function () {
      testProgress.hidden = true;
      testIdle.hidden = false;
    });
  });

  /* ---------------- deal cards ---------------- */

  function render(slug, coupons) {
    var mine = coupons.filter(function (c) { return c.store_slug === slug; });
    if (!mine.length) {
      emptyEl.hidden = false;
      return;
    }
    mine.sort(function (a, b) {
      return (b.verified_date || "").localeCompare(a.verified_date || "");
    });
    mine.forEach(function (c) {
      var card = document.createElement("div");
      card.className = "deal";
      var title = c.title || "Deal";
      var meta = [];
      var vl = verifiedLabel(c);
      if (vl) meta.push(vl);
      if (c.code) meta.push("Code needed");
      card.innerHTML =
        '<div class="d-title">' + esc(title) + "</div>" +
        '<div class="d-meta">' + esc(meta.join(" · ")) + "</div>" +
        '<div class="d-actions">' +
        '<button class="btn btn-copy">Copy code</button>' +
        '<button class="btn btn-apply">Fill at checkout</button>' +
        "</div>";
      var copyBtn = card.querySelector(".btn-copy");
      var applyBtn = card.querySelector(".btn-apply");

      if (c.code) {
        var codeEl = document.createElement("div");
        codeEl.innerHTML = '<span class="d-code">' + esc(c.code) + "</span>";
        card.insertBefore(codeEl, card.querySelector(".d-actions"));
      } else {
        copyBtn.textContent = "Open store deal";
      }

      copyBtn.addEventListener("click", function () {
        if (c.code) {
          navigator.clipboard.writeText(c.code).then(function () {
            copyBtn.textContent = "Copied! 🎉";
            setTimeout(function () { copyBtn.textContent = "Copy code"; }, 1600);
          });
          return;
        }
        var go = c.id ? SITE + "/go/" + c.id + "/" : SITE + "/stores/" + slug + "/";
        chrome.tabs.create({ url: go });
      });

      applyBtn.addEventListener("click", function () {
        if (!c.code) return;
        sendToTab({ type: "cc-apply-code", code: c.code });
      });

      listEl.appendChild(card);
    });
  }

  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    var url = tabs && tabs[0] ? tabs[0].url : "";
    if (tabs && tabs[0]) activeTabId = tabs[0].id;
    var host = "";
    try { host = new URL(url).hostname; } catch (e) {}
    var hit = storeForHost(host);
    chrome.storage.local.get(["cc_coupons", "cc_affiliate_links"], function (res) {
      var coupons = res.cc_coupons || [];
      if (!hit) {
        noStoreEl.hidden = false;
        countEl.textContent = (CC_STORES || []).length;
        storeEl.textContent = "Browsing " + (host || "the web");
        return;
      }
      storeEl.textContent = "Deals for " + hit.name;
      render(hit.slug, coupons);
      /* Explicit "Shop" click only — never injected into the user's own
         navigation. Uses the same affiliate URLs as the site. */
      var links = res.cc_affiliate_links || {};
      var entry = links[hit.slug] || {};
      var shopUrl = resolveShopUrl(entry.affiliate || "", entry.url || "", hit.slug);
      if (shopUrl) {
        shopLink.href = shopUrl;
        shopLink.textContent = entry.affiliate
          ? "Shop " + hit.name + " (supports Penny)"
          : "Shop " + hit.name;
        shopLink.hidden = false;
        shopDot.hidden = false;
      }
      /* Ask the page whether this is a checkout with testable codes. */
      sendToTab({ type: "cc-autotest-query" }, function (resp) {
        if (resp && resp.isCheckout && resp.codeCount > 0 && !resp.testing) {
          testSub.textContent = "Penny can try " + resp.codeCount + " code" +
            (resp.codeCount > 1 ? "s" : "") + " for " + hit.name + ", one by one.";
          testBox.hidden = false;
        } else if (resp && resp.testing) {
          testSub.textContent = "Penny is testing your codes right now — watch the page!";
          testBox.hidden = false;
          testIdle.hidden = true;
          testProgress.hidden = false;
        }
      });
    });
  });
})();
