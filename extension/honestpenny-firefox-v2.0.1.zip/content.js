/* Honest Penny v2 - content script.
 *
 * Runs on supported retailer domains (matches generated at build time).
 *  - Slide-in: on product/store pages, a cute Penny slide-in (bottom-left,
 *    dismissible, once per domain per day) when the store has cached coupons.
 *    On CHECKOUT pages it becomes "Test N codes at checkout" - Penny tries
 *    each code only after the user clicks. Never auto-runs.
 *  - Auto-test progress overlay with a cancel button while codes are tried.
 *  - Listens for {type:"cc-apply-code", code} from the popup: finds the
 *    retailer's promo-code field, fills it, highlights it, shows a toast.
 *    NEVER auto-submits anything. NEVER touches payment/login fields.
 *  - Answers popup queries: {type:"cc-autotest-query"} and starts tests on
 *    {type:"cc-autotest-start"}.
 *
 * No tracking, no analytics, no data sent anywhere.
 * (cc-config.js is baked in at package time; CC_EXT_CONFIG is cached by
 * the background worker from the site's public extension-config.json.)
 */

/* global CC_STORES, PennyAuto */

/* Remote retailer tuning for the auto-test engine (data only, never code).
 * Populated async from chrome.storage.local (written by background.js from
 * the site's public data/extension-config.json). autoapply.js reads this
 * global and falls back to built-in defaults until it arrives. */
var CC_EXT_CONFIG = null;
try {
  chrome.storage.local.get(["cc_ext_config"], function (res) {
    CC_EXT_CONFIG = (res && res.cc_ext_config) || null;
  });
} catch (e) {}

/* User preferences from the options page (all local). Read once at load;
 * auto-test only starts on user click, so these are settled by then. */
var CC_USER_MAX_CODES = 0;
var CC_USER_SLIDEIN = "daily";
try {
  chrome.storage.local.get(["cc_opt_max_codes", "cc_opt_slidein"], function (res) {
    if (res) {
      CC_USER_MAX_CODES = parseInt(res.cc_opt_max_codes || 0, 10) || 0;
      CC_USER_SLIDEIN = res.cc_opt_slidein || "daily";
    }
  });
} catch (e) {}

(function () {
  "use strict";

  var testing = null; /* active test session handle */

  function storeForHost(host) {
    host = (host || "").toLowerCase();
    for (var i = 0; i < (CC_STORES || []).length; i++) {
      var d = CC_STORES[i].domain;
      if (host === d || host.slice(-d.length - 1) === "." + d) return CC_STORES[i];
    }
    return null;
  }

  var hit = storeForHost(location.hostname);
  if (!hit) return;

  /* ---------------- shared Penny art + toast ---------------- */

  var PENNY_SVG =
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="54" height="54" aria-hidden="true">' +
    '<ellipse cx="64" cy="70" rx="45" ry="36" fill="#FF8A7A"/>' +
    '<polygon points="40,46 30,22 55,35" fill="#FF8A7A"/>' +
    '<polygon points="88,46 98,22 73,35" fill="#FF8A7A"/>' +
    '<ellipse cx="64" cy="92" rx="27" ry="20" fill="#FFF3DC"/>' +
    '<rect x="50" y="30" width="28" height="7" rx="3.5" fill="#4A3728"/>' +
    '<path d="M42,60 q8,-9 16,0" fill="none" stroke="#4A3728" stroke-width="4.5" stroke-linecap="round"/>' +
    '<path d="M70,60 q8,-9 16,0" fill="none" stroke="#4A3728" stroke-width="4.5" stroke-linecap="round"/>' +
    '<ellipse cx="33" cy="72" rx="8" ry="5.5" fill="#FFB59E" opacity="0.8"/>' +
    '<ellipse cx="95" cy="72" rx="8" ry="5.5" fill="#FFB59E" opacity="0.8"/>' +
    '<ellipse cx="64" cy="76" rx="14" ry="11" fill="#F2736A"/>' +
    '<ellipse cx="58" cy="76" rx="3" ry="4.5" fill="#4A3728"/>' +
    '<ellipse cx="70" cy="76" rx="3" ry="4.5" fill="#4A3728"/>' +
    '<path d="M56,90 q8,7 16,0" fill="none" stroke="#4A3728" stroke-width="4" stroke-linecap="round"/>' +
    "</svg>";

  function todayKey() {
    var d = new Date();
    return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate();
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function pennyToast(msg, ms) {
    var t = document.createElement("div");
    t.setAttribute("role", "status");
    t.style.cssText =
      "position:fixed;left:50%;bottom:28px;transform:translateX(-50%) translateY(16px);" +
      "z-index:2147483647;background:#4A3728;color:#FFF8F0;font-weight:700;font-size:14px;" +
      "padding:12px 22px;border-radius:999px;box-shadow:0 8px 24px rgba(0,0,0,.25);" +
      "font-family:ui-rounded,'Arial Rounded MT Bold',system-ui,sans-serif;" +
      "transition:transform .3s ease,opacity .3s ease;opacity:0;max-width:92vw;text-align:center;";
    t.textContent = msg;
    document.documentElement.appendChild(t);
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        t.style.transform = "translateX(-50%) translateY(0)";
        t.style.opacity = "1";
      });
    });
    setTimeout(function () {
      t.style.opacity = "0";
      setTimeout(function () { t.remove(); }, 400);
    }, ms || 3600);
  }

  function getCoupons(cb) {
    try {
      chrome.storage.local.get(["cc_coupons"], function (res) {
        var all = res.cc_coupons || [];
        cb(all.filter(function (c) { return c.store_slug === hit.slug; }));
      });
    } catch (e) { cb([]); }
  }

  /* ---------------- slide-in ---------------- */

  function maybeSlideIn() {
    var slideinMode = "daily";
    try { slideinMode = (typeof CC_USER_SLIDEIN !== "undefined" && CC_USER_SLIDEIN) || "daily"; } catch (e) {}
    if (slideinMode === "never") return;
    var dismissKey = "cc_dismiss_" + hit.slug + "_" + todayKey();
    chrome.storage.local.get(["cc_coupons", dismissKey], function (res) {
      if (slideinMode !== "always" && res[dismissKey]) return;
      var coupons = res.cc_coupons || [];
      var mine = coupons.filter(function (c) { return c.store_slug === hit.slug; });
      if (!mine.length) return;

      var codeCount = mine.filter(function (c) { return c.code; }).length;
      var onCheckout = false;
      try { onCheckout = window.PennyAuto && PennyAuto.isCheckoutPage(hit.slug); } catch (e) {}

      var headline, ctaLabel;
      if (onCheckout && codeCount > 0) {
        headline = "You're at checkout! Penny can test " + codeCount + " code" + (codeCount > 1 ? "s" : "") + " for " + escapeHtml(hit.name) + ".";
        ctaLabel = "Test my codes";
      } else {
        headline = "Penny found " + mine.length + " deal" + (mine.length > 1 ? "s" : "") + " for " + escapeHtml(hit.name) + "!";
        ctaLabel = "Show my deals";
      }

      var box = document.createElement("div");
      box.id = "cc-penny-slide";
      box.setAttribute("role", "dialog");
      box.setAttribute("aria-label", "Honest Penny deals for " + hit.name);
      box.style.cssText =
        "position:fixed;left:16px;bottom:16px;z-index:2147483647;" +
        "display:flex;align-items:center;gap:12px;max-width:min(360px,calc(100vw - 32px));" +
        "background:#FFF8F0;border:2px solid #FF7B6B;border-radius:22px;" +
        "box-shadow:0 12px 32px rgba(74,55,40,.25);padding:12px 14px;" +
        "font-family:ui-rounded,'Arial Rounded MT Bold','Helvetica Rounded',system-ui,sans-serif;" +
        "color:#4A3728;transform:translateY(24px);opacity:0;" +
        "transition:transform .35s ease,opacity .35s ease;";
      box.innerHTML =
        '<div style="flex:none">' + PENNY_SVG + "</div>" +
        '<div style="flex:1;min-width:0">' +
        '<div style="font-weight:800;font-size:14px;line-height:1.3">' + headline + "</div>" +
        (onCheckout && codeCount > 0
          ? '<div style="font-size:11px;color:#8A6A55;margin-top:4px">Only with your click. Penny never checks out for you.</div>'
          : "") +
        '<button id="cc-penny-open" style="margin-top:8px;border:0;cursor:pointer;' +
        "background:#FF7B6B;color:#4A3728;font-weight:800;font-size:13px;" +
        'padding:8px 16px;border-radius:999px;font-family:inherit">' + ctaLabel + "</button>" +
        "</div>" +
        '<button id="cc-penny-x" aria-label="Dismiss" style="flex:none;align-self:flex-start;' +
        "border:0;background:none;cursor:pointer;font-size:16px;color:#8A6A55;line-height:1;" +
        'font-family:inherit">\u00d7</button>';

      document.documentElement.appendChild(box);
      requestAnimationFrame(function () {
        requestAnimationFrame(function () {
          box.style.transform = "translateY(0)";
          box.style.opacity = "1";
        });
      });

      var done = false;
      function dismiss(persist) {
        if (done) return; done = true;
        if (persist) {
          var o = {}; o[dismissKey] = true;
          chrome.storage.local.set(o);
        }
        box.style.transform = "translateY(24px)";
        box.style.opacity = "0";
        setTimeout(function () { box.remove(); }, 400);
      }
      box.querySelector("#cc-penny-x").addEventListener("click", function () { dismiss(true); });
      box.querySelector("#cc-penny-open").addEventListener("click", function () {
        dismiss(false);
        if (onCheckout && codeCount > 0) {
          startAutoTest();
        } else {
          chrome.runtime.sendMessage({ type: "cc-open-popup", slug: hit.slug });
        }
      });
    });
  }

  /* ---------------- auto-test progress overlay ---------------- */

  var overlay = null, overlayBar = null, overlayMsg = null;

  function showOverlay() {
    hideOverlay();
    overlay = document.createElement("div");
    overlay.id = "cc-penny-test";
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-label", "Penny is testing your codes");
    overlay.style.cssText =
      "position:fixed;right:16px;bottom:16px;z-index:2147483647;width:min(320px,calc(100vw - 32px));" +
      "background:#FFF8F0;border:2px solid #FF7B6B;border-radius:22px;color:#4A3728;" +
      "box-shadow:0 12px 32px rgba(74,55,40,.25);padding:14px 16px;" +
      "font-family:ui-rounded,'Arial Rounded MT Bold',system-ui,sans-serif;";
    overlay.innerHTML =
      '<div style="display:flex;align-items:center;gap:10px">' +
      '<div style="flex:none">' + PENNY_SVG + "</div>" +
      '<div style="font-weight:800;font-size:14px">Penny\u2019s testing your codes\u2026</div>' +
      "</div>" +
      '<div id="cc-test-msg" style="font-size:12px;color:#8A6A55;margin:8px 0 6px">Getting ready\u2026</div>' +
      '<div style="height:10px;background:#F7DCC9;border-radius:999px;overflow:hidden">' +
      '<div id="cc-test-bar" style="height:100%;width:0%;background:#2FBF9B;border-radius:999px;transition:width .3s ease"></div>' +
      "</div>" +
      '<button id="cc-test-cancel" style="margin-top:10px;border:0;cursor:pointer;background:none;' +
      'color:#8A6A55;font-weight:700;font-size:12px;font-family:inherit">Cancel</button>';
    document.documentElement.appendChild(overlay);
    overlayBar = overlay.querySelector("#cc-test-bar");
    overlayMsg = overlay.querySelector("#cc-test-msg");
    overlay.querySelector("#cc-test-cancel").addEventListener("click", function () {
      if (testing) testing.cancel();
      pennyToast("Penny stopped testing. Your cart is untouched.");
      hideOverlay();
      broadcast({ type: "cc-autotest-done", ok: false, reason: "cancelled", tried: 0 });
    });
  }

  function hideOverlay() {
    if (overlay) { overlay.remove(); overlay = null; }
  }

  function broadcast(msg) {
    try { chrome.runtime.sendMessage(msg); } catch (e) {}
  }

  /* ---------------- start a test session ---------------- */

  function startAutoTest() {
    if (testing) { pennyToast("Penny is already testing your codes!"); return; }
    getCoupons(function (mine) {
      var codes = mine.filter(function (c) { return c.code; });
      if (!codes.length) {
        pennyToast("No codes to test for this store right now.");
        broadcast({ type: "cc-autotest-done", ok: false, reason: "no-codes", tried: 0 });
        return;
      }
      showOverlay();
      testing = PennyAuto.testCodes(hit.slug, codes, {
        onProgress: function (p) {
          if (overlayBar) overlayBar.style.width = Math.round((p.done / p.total) * 100) + "%";
          if (overlayMsg) {
            var label = p.status === "worked" ? "worked!" : (p.status === "rejected" ? "didn't take" : (p.status === "testing" ? "trying\u2026" : p.status));
            var n = p.status === "testing" ? p.done + 1 : p.done;
            overlayMsg.textContent = "Code " + n + " of " + p.total + ": " + p.code + " \u2014 " + label;
          }
          broadcast({ type: "cc-autotest-progress", done: p.done, total: p.total, code: p.code, status: p.status });
        },
        onDone: function (r) {
          testing = null;
          hideOverlay();
          broadcast({ type: "cc-autotest-done", ok: r.ok, saved: r.saved || 0, code: r.code || "", tried: r.tried || 0, reason: r.reason || "" });
          if (r.ok && r.saved > 0) {
            pennyToast("Penny saved you $" + r.saved.toFixed(2) + " with " + r.code + "! \uD83D\uDC37");
          } else if (r.ok) {
            pennyToast("Best code applied: " + r.code + ". Penny kept the lowest total.");
          } else if (r.reason === "no-field") {
            pennyToast("Penny couldn't find the promo box on this page \u2014 try the cart page!");
          } else if (r.reason !== "cancelled" && r.reason !== "navigated") {
            pennyToast("None of the codes worked this time. Penny will keep hunting.");
          }
        }
      });
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", maybeSlideIn);
  } else {
    maybeSlideIn();
  }

  /* ---------------- popup messages ---------------- */

  var PROMO_SELECTORS = [
    'input[name*="promo" i]', 'input[name*="coupon" i]', 'input[name*="discount" i]',
    'input[name*="voucher" i]', 'input[id*="promo" i]', 'input[id*="coupon" i]',
    'input[id*="discount" i]', "#promo-code", "#coupon-code", "#promocode",
    ".promo-code-input", ".coupon-code-input",
    'input[placeholder*="promo" i]', 'input[placeholder*="coupon" i]',
    'input[placeholder*="discount" i]', 'input[aria-label*="promo" i]',
    'input[aria-label*="coupon" i]'
  ];

  function findPromoFieldLegacy() {
    for (var i = 0; i < PROMO_SELECTORS.length; i++) {
      var el = document.querySelector(PROMO_SELECTORS[i]);
      if (el && el.offsetParent !== null && !el.disabled && el.type !== "hidden") return el;
    }
    return null;
  }

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (!msg) return;
    if (msg.type === "cc-apply-code" && msg.code) {
      var field = null;
      try { field = PennyAuto.findPromoField(hit.slug); } catch (e) {}
      if (!field) field = findPromoFieldLegacy();
      if (!field) {
        pennyToast("Penny couldn't find the promo box on this page \u2014 paste it at checkout!");
        return;
      }
      field.focus();
      var proto = field.tagName === "TEXTAREA"
        ? window.HTMLTextAreaElement.prototype
        : window.HTMLInputElement.prototype;
      var setter = Object.getOwnPropertyDescriptor(proto, "value").set;
      setter.call(field, msg.code);
      field.dispatchEvent(new Event("input", { bubbles: true }));
      field.dispatchEvent(new Event("change", { bubbles: true }));
      field.style.outline = "3px solid #FF7B6B";
      field.style.outlineOffset = "2px";
      field.style.borderRadius = "8px";
      try { field.scrollIntoView({ behavior: "smooth", block: "center" }); } catch (e) {}
      pennyToast("Penny pasted your code \u2014 hit Apply! \uD83D\uDC37");
      return;
    }
    if (msg.type === "cc-autotest-query") {
      var isCheckout = false;
      try { isCheckout = PennyAuto.isCheckoutPage(hit.slug); } catch (e) {}
      getCoupons(function (mine) {
        sendResponse({
          isCheckout: isCheckout,
          codeCount: mine.filter(function (c) { return c.code; }).length,
          testing: !!testing,
          slug: hit.slug,
          name: hit.name
        });
      });
      return true; /* async response */
    }
    if (msg.type === "cc-autotest-start") {
      startAutoTest();
      sendResponse({ started: true });
      return;
    }
    if (msg.type === "cc-autotest-cancel") {
      if (testing) testing.cancel();
      sendResponse({ ok: true });
    }
  });
})();
