/* Honest Penny v2 — options page logic. All settings stay local. */
(function () {
  "use strict";

  var maxCodesEl = document.getElementById("opt-max-codes");
  var slideinEl = document.getElementById("opt-slidein");
  var resetBtn = document.getElementById("opt-reset-savings");
  var savedNote = document.getElementById("opt-saved");
  var savingsDetail = document.getElementById("opt-savings-detail");

  var noteTimer = null;
  function note(msg) {
    savedNote.textContent = msg;
    clearTimeout(noteTimer);
    noteTimer = setTimeout(function () { savedNote.textContent = ""; }, 2500);
  }

  chrome.storage.local.get(
    ["cc_opt_max_codes", "cc_opt_slidein", "cc_saved_total", "cc_saved_count"],
    function (res) {
      maxCodesEl.value = String(res.cc_opt_max_codes || 10);
      slideinEl.value = res.cc_opt_slidein || "daily";
      var total = parseFloat(res.cc_saved_total || 0);
      var count = parseInt(res.cc_saved_count || 0, 10);
      savingsDetail.textContent = total > 0
        ? "$" + total.toFixed(2) + " across " + count + " winning code" + (count === 1 ? "" : "s")
        : "Nothing saved yet — go test some codes!";
    }
  );

  maxCodesEl.addEventListener("change", function () {
    chrome.storage.local.set({ cc_opt_max_codes: parseInt(maxCodesEl.value, 10) }, function () {
      note("Saved! Penny will test up to " + maxCodesEl.value + " codes.");
    });
  });

  slideinEl.addEventListener("change", function () {
    chrome.storage.local.set({ cc_opt_slidein: slideinEl.value }, function () {
      note("Saved!");
    });
  });

  resetBtn.addEventListener("click", function () {
    if (!confirm("Reset Penny's savings tracker to $0.00?")) return;
    chrome.storage.local.set({ cc_saved_total: 0, cc_saved_count: 0 }, function () {
      savingsDetail.textContent = "Nothing saved yet — go test some codes!";
      note("Savings tracker reset.");
    });
  });
})();
