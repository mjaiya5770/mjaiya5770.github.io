/* Honest Penny v2 - background service worker (MV3).
 *
 * What it does:
 *  - On install and every 24h (alarms), fetches SITE_URL/data/coupons.json
 *    (the public JSON feed the static site already publishes) and caches it
 *    in chrome.storage.local with a timestamp.
 *  - Also fetches SITE_URL/data/extension-config.json (per-store checkout
 *    tuning for the auto-test engine) and SITE_URL/data/affiliate-links.json
 *    (per-store shop URLs, so explicit "Shop" clicks can support Penny).
 *  - Sets the toolbar badge to the coupon count when the active tab is on a
 *    supported store.
 *  - Opens the welcome page on first install.
 *
 * What it does NOT do: no analytics, no tracking, no remote code, no data
 * sent anywhere. The only network requests are the public JSON feeds above.
 * (cc-config.js is generated at package time and baked into the zip.)
 */

/* global CC_SITE_URL, CC_STORES */
try { importScripts("cc-config.js"); } catch (e) { /* Firefox: loaded via manifest scripts array */ }

var SITE = (typeof CC_SITE_URL !== "undefined" ? CC_SITE_URL : "");
var FEED_URL = SITE + "/data/coupons.json";
var CONFIG_URL = SITE + "/data/extension-config.json";
var AFFILIATE_URL = SITE + "/data/affiliate-links.json";
var BADGE_COLOR = "#FF7B6B";

function fetchJson(url) {
  return fetch(url, { cache: "no-store" }).then(function (r) {
    if (!r.ok) throw new Error("feed " + r.status);
    return r.json();
  });
}

function refreshCoupons() {
  if (!FEED_URL || FEED_URL.charAt(0) === "/") return;
  fetchJson(FEED_URL).then(function (data) {
    chrome.storage.local.set({
      cc_coupons: Array.isArray(data) ? data : (data.coupons || []),
      cc_fetched_at: Date.now()
    });
  }).catch(function () { /* stay on the last cached copy; retry in 24h */ });
  /* Retailer tuning for the auto-test engine (data only, never code).
     Content scripts read it from storage into their own context. */
  fetchJson(CONFIG_URL).then(function (data) {
    chrome.storage.local.set({ cc_ext_config: data, cc_ext_config_at: Date.now() });
  }).catch(function () {});
  /* Per-store shop URLs for explicit "Shop" clicks in the popup. */
  fetchJson(AFFILIATE_URL).then(function (data) {
    chrome.storage.local.set({ cc_affiliate_links: data || {} });
  }).catch(function () {});
}

function storeForUrl(url) {
  if (typeof CC_STORES === "undefined") return null;
  var host = "";
  try { host = new URL(url).hostname.toLowerCase(); } catch (e) { return null; }
  for (var i = 0; i < CC_STORES.length; i++) {
    var d = CC_STORES[i].domain;
    if (host === d || host.endsWith("." + d)) return CC_STORES[i];
  }
  return null;
}

function countForStore(slug, coupons) {
  var n = 0;
  for (var i = 0; i < coupons.length; i++) {
    if (coupons[i].store_slug === slug) n++;
  }
  return n;
}

function updateBadge(tabId, url) {
  var hit = storeForUrl(url);
  if (!hit) {
    chrome.action.setBadgeText({ text: "", tabId: tabId });
    return;
  }
  chrome.storage.local.get(["cc_coupons"], function (res) {
    var coupons = res.cc_coupons || [];
    var n = countForStore(hit.slug, coupons);
    try {
      chrome.action.setBadgeBackgroundColor({ color: BADGE_COLOR, tabId: tabId });
      chrome.action.setBadgeText({ text: n > 0 ? String(n) : "", tabId: tabId });
      chrome.action.setTitle({ title: "Honest Penny - " + n + " deals at " + hit.name, tabId: tabId });
    } catch (e) { /* badge API hiccup: non-fatal */ }
  });
}

chrome.runtime.onInstalled.addListener(function (details) {
  refreshCoupons();
  try { chrome.alarms.create("cc-refresh", { periodInMinutes: 24 * 60 }); } catch (e) {}
  /* First-run onboarding: show what Penny does and what she never does. */
  if (details && details.reason === "install") {
    try { chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") }); } catch (e) {}
  }
});

chrome.alarms.onAlarm.addListener(function (alarm) {
  if (alarm && alarm.name === "cc-refresh") refreshCoupons();
});

chrome.tabs.onUpdated.addListener(function (tabId, info, tab) {
  if (info.status === "complete" && tab && tab.url) updateBadge(tabId, tab.url);
});

chrome.tabs.onActivated.addListener(function (active) {
  chrome.tabs.get(active.tabId, function (tab) {
    if (tab && tab.url) updateBadge(active.tabId, tab.url);
  });
});

/* Popup/slide-in helper: try to open the toolbar popup on user click,
 * fall back to the store page on the site. */
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (msg && msg.type === "cc-open-popup") {
    var opened = false;
    var openStorePage = function () {
      if (opened) return;
      opened = true;
      chrome.tabs.create({
        url: (typeof CC_SITE_URL !== "undefined" ? CC_SITE_URL : "") +
          "/stores/" + (msg.slug || "") + "/"
      });
    };
    try {
      var p = chrome.action.openPopup();
      if (p && typeof p.then === "function") {
        p.then(function () { opened = true; }, openStorePage);
      } else {
        opened = true; /* non-promise environment: assume it worked */
      }
    } catch (e) { openStorePage(); }
    sendResponse({ ok: true });
  }
});
