/* Honest Penny popup logic.
 * Reads cached coupons from chrome.storage.local (written by background.js).
 * Codes are revealed only on click; no code is sent anywhere.
 */
/* global CC_SITE_URL, CC_STORES */
(function () {
  "use strict";

  var listEl = document.getElementById("pop-list");
  var emptyEl = document.getElementById("pop-empty");
  var noStoreEl = document.getElementById("pop-nostore");
  var storeEl = document.getElementById("pop-store");
  var countEl = document.getElementById("pop-count");
  var siteLink = document.getElementById("pop-site");
  var SITE = (typeof CC_SITE_URL !== "undefined" ? CC_SITE_URL : "https://honest-penny.vercel.app");

  siteLink.href = SITE + "/";

  function storeForHost(host) {
    host = (host || "").toLowerCase();
    for (var i = 0; i < (CC_STORES || []).length; i++) {
      var d = CC_STORES[i].domain;
      if (host === d || host.slice(-d.length - 1) === "." + d) return CC_STORES[i];
    }
    return null;
  }

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function render(slug, coupons) {
    var mine = coupons.filter(function (c) { return c.store_slug === slug; });
    if (!mine.length) {
      emptyEl.hidden = false;
      return;
    }
    mine.sort(function (a, b) {
      return (b.verified_date || "").localeCompare(a.verified_date || "");
    });
    mine.forEach(function (c) {
      var card = document.createElement("div");
      card.className = "deal";
      var title = c.title || "Deal";
      var meta = [];
      if (c.verified_date) meta.push("Verified " + c.verified_date);
      if (c.code) meta.push("Code needed");
      card.innerHTML =
        '<div class="d-title">' + esc(title) + "</div>" +
        '<div class="d-meta">' + esc(meta.join(" · ")) + "</div>" +
        '<div class="d-actions">' +
        '<button class="btn btn-copy">Copy code</button>' +
        '<button class="btn btn-apply">Fill at checkout</button>' +
        "</div>";
      var copyBtn = card.querySelector(".btn-copy");
      var applyBtn = card.querySelector(".btn-apply");

      if (c.code) {
        var codeEl = document.createElement("div");
        codeEl.innerHTML = '<span class="d-code">' + esc(c.code) + "</span>";
        card.insertBefore(codeEl, card.querySelector(".d-actions"));
      } else {
        copyBtn.textContent = "Open store deal";
      }

      copyBtn.addEventListener("click", function () {
        if (c.code) {
          navigator.clipboard.writeText(c.code).then(function () {
            copyBtn.textContent = "Copied! 🎉";
            setTimeout(function () { copyBtn.textContent = "Copy code"; }, 1600);
          });
        }
        var go = c.id ? SITE + "/go/" + c.id + "/" : SITE + "/stores/" + slug + "/";
        chrome.tabs.create({ url: go });
      });

      applyBtn.addEventListener("click", function () {
        if (!c.code) return;
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
          if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: "cc-apply-code", code: c.code });
        });
      });

      listEl.appendChild(card);
    });
  }

  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    var url = tabs && tabs[0] ? tabs[0].url : "";
    var host = "";
    try { host = new URL(url).hostname; } catch (e) {}
    var hit = storeForHost(host);
    chrome.storage.local.get(["cc_coupons"], function (res) {
      var coupons = res.cc_coupons || [];
      if (!hit) {
        noStoreEl.hidden = false;
        countEl.textContent = (CC_STORES || []).length;
        storeEl.textContent = "Browsing " + (host || "the web");
        return;
      }
      storeEl.textContent = "Deals for " + hit.name;
      render(hit.slug, coupons);
    });
  });
})();
