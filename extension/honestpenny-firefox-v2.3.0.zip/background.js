/* Honest Penny v2 - background service worker (MV3).
 *
 * What it does:
 *  - On install and every 24h (alarms), fetches SITE_URL/data/coupons.json
 *    (the public JSON feed the static site already publishes) and caches it
 *    in chrome.storage.local with a timestamp.
 *  - Also fetches SITE_URL/data/extension-config.json (per-store checkout
 *    tuning for the auto-test engine) and SITE_URL/data/affiliate-links.json
 *    (per-store shop URLs, so explicit "Shop" clicks can support Penny).
 *  - Sets the toolbar badge to the coupon count when the active tab is on a
 *    supported store.
 *  - Opens the welcome page on first install.
 *
 *  - v2.1 account bridge: when the user signs in (their choice, in the
 *    popup) it talks to SITE/api/ext - minting one-time pass-through
 *    links to the site and logging the user's own deal wins to their
 *    account piggybank. Only ever on the user's own actions.
 *
 * What it does NOT do: no analytics, no tracking, no remote code. Apart
 * from the account bridge above (user-initiated only), the only network
 * requests are the public JSON feeds above.
 * (cc-config.js is generated at package time and baked into the zip.)
 */

/* global CC_SITE_URL, CC_STORES */
try { importScripts("cc-config.js"); } catch (e) { /* Firefox: loaded via manifest scripts array */ }

var SITE = (typeof CC_SITE_URL !== "undefined" ? CC_SITE_URL : "");
var FEED_URL = SITE + "/data/coupons.json";
var CONFIG_URL = SITE + "/data/extension-config.json";
var AFFILIATE_URL = SITE + "/data/affiliate-links.json";
var BADGE_COLOR = "#FF7B6B";

function fetchJson(url) {
  return fetch(url, { cache: "no-store" }).then(function (r) {
    if (!r.ok) throw new Error("feed " + r.status);
    return r.json();
  });
}

function refreshCoupons() {
  if (!FEED_URL || FEED_URL.charAt(0) === "/") return;
  fetchJson(FEED_URL).then(function (data) {
    chrome.storage.local.set({
      cc_coupons: Array.isArray(data) ? data : (data.coupons || []),
      cc_fetched_at: Date.now()
    });
  }).catch(function () { /* stay on the last cached copy; retry in 24h */ });
  /* Retailer tuning for the auto-test engine (data only, never code).
     Content scripts read it from storage into their own context. */
  fetchJson(CONFIG_URL).then(function (data) {
    chrome.storage.local.set({ cc_ext_config: data, cc_ext_config_at: Date.now() });
  }).catch(function () {});
  /* Per-store shop URLs for explicit "Shop" clicks in the popup. */
  fetchJson(AFFILIATE_URL).then(function (data) {
    chrome.storage.local.set({ cc_affiliate_links: data || {} });
  }).catch(function () {});
}

function storeForUrl(url) {
  if (typeof CC_STORES === "undefined") return null;
  var host = "";
  try { host = new URL(url).hostname.toLowerCase(); } catch (e) { return null; }
  for (var i = 0; i < CC_STORES.length; i++) {
    var d = CC_STORES[i].domain;
    if (host === d || host.endsWith("." + d)) return CC_STORES[i];
  }
  return null;
}

function countForStore(slug, coupons) {
  var n = 0;
  for (var i = 0; i < coupons.length; i++) {
    if (coupons[i].store_slug === slug) n++;
  }
  return n;
}

function updateBadge(tabId, url) {
  var hit = storeForUrl(url);
  if (!hit) {
    chrome.action.setBadgeText({ text: "", tabId: tabId });
    return;
  }
  chrome.storage.local.get(["cc_coupons"], function (res) {
    var coupons = res.cc_coupons || [];
    var n = countForStore(hit.slug, coupons);
    try {
      chrome.action.setBadgeBackgroundColor({ color: BADGE_COLOR, tabId: tabId });
      chrome.action.setBadgeText({ text: n > 0 ? String(n) : "", tabId: tabId });
      chrome.action.setTitle({ title: "Honest Penny - " + n + " deals at " + hit.name, tabId: tabId });
    } catch (e) { /* badge API hiccup: non-fatal */ }
  });
}

chrome.runtime.onInstalled.addListener(function (details) {
  refreshCoupons();
  try { chrome.alarms.create("cc-refresh", { periodInMinutes: 24 * 60 }); } catch (e) {}
  /* First-run onboarding: show what Penny does and what she never does. */
  if (details && details.reason === "install") {
    try { chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") }); } catch (e) {}
  }
});

chrome.alarms.onAlarm.addListener(function (alarm) {
  if (alarm && alarm.name === "cc-refresh") refreshCoupons();
});

chrome.tabs.onUpdated.addListener(function (tabId, info, tab) {
  if (info.status === "complete" && tab && tab.url) updateBadge(tabId, tab.url);
});

chrome.tabs.onActivated.addListener(function (active) {
  chrome.tabs.get(active.tabId, function (tab) {
    if (tab && tab.url) updateBadge(active.tabId, tab.url);
  });
});

/* ---------------- account bridge (v2.1) ----------------
 * The extension can sign in to the SAME account as the website
 * (POST SITE/api/ext). The raw extension token lives only in
 * chrome.storage.local and is attached here, in the service worker, so
 * content scripts (which run on retailer pages) never see it.
 * Pass-through: the popup asks for a handoff; the API mints a
 * single-use 2-minute login URL and the popup opens it in a tab - the
 * site exchanges it for its normal session cookie and lands on the
 * requested page (piggybank, a deal) already signed in. */
function extApi(payload, cb) {
  chrome.storage.local.get(["cc_ext_token"], function (res) {
    var body = {};
    for (var k in payload) body[k] = payload[k];
    if (body.action !== "login" && res.cc_ext_token) body.token = res.cc_ext_token;
    fetch(SITE + "/api/ext", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    }).then(function (r) { return r.json(); })
      .then(function (j) { cb(j || {}); })
      .catch(function () { cb({ ok: false, error: "network" }); });
  });
}

function clearExtSession() {
  try { chrome.storage.local.remove(["cc_ext_token", "cc_ext_email"]); } catch (e) {}
}

/* ---------------- serialized savings ledger ----------------
 * Content scripts report each verified win here. The service worker is
 * the single writer and applies events one at a time, so two tabs
 * finishing together can't lose each other's savings to a
 * read-modify-write race. Event ids dedupe retries. */
var savingsChain = Promise.resolve();

function recordSavingsSerialized(msg) {
  var amt = parseFloat(msg.amount) || 0;
  if (!(amt > 0)) return;
  var eid = String(msg.eventId || "");
  savingsChain = savingsChain.then(function () {
    return new Promise(function (resolve) {
      chrome.storage.local.get(["cc_saved_total", "cc_saved_count", "cc_save_ids"], function (res) {
        var ids = res.cc_save_ids || [];
        if (eid && ids.indexOf(eid) !== -1) { resolve(); return; }
        var total = parseFloat(res.cc_saved_total || 0) + amt;
        var count = parseInt(res.cc_saved_count || 0, 10) + 1;
        if (eid) { ids.push(eid); ids = ids.slice(-50); }
        chrome.storage.local.set({
          cc_saved_total: Math.round(total * 100) / 100,
          cc_saved_count: count,
          cc_save_ids: ids,
          cc_last_save: { amount: Math.round(amt * 100) / 100, code: msg.code || "", store: msg.store || "", at: Date.now() }
        }, function () { resolve(); });
      });
    });
  });
}

/* Popup/slide-in helper: try to open the toolbar popup on user click,
 * fall back to the store page on the site. */
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (msg && msg.type === "cc-reset-savings") {
    /* The reset goes through the SAME serialized chain as savings
       events: a direct storage write from the options page could be
       overwritten by an in-flight savings event (or erase one). */
    savingsChain = savingsChain.then(function () {
      return new Promise(function (resolve) {
        chrome.storage.local.set({
          cc_saved_total: 0, cc_saved_count: 0,
          cc_save_ids: [], cc_last_save: null
        }, function () { resolve(); });
      });
    });
    savingsChain.then(function () { sendResponse({ ok: true }); });
    return true;
  }
  if (msg && msg.type === "cc-record-savings") {
    recordSavingsSerialized(msg);
    sendResponse({ ok: true });
    return;
  }
  if (msg && msg.type === "cc-ext-login") {
    var loginPayload = { action: "login", email: msg.email || "" };
    loginPayload["password"] = msg["password"] || "";
    extApi(loginPayload, function (j) {
      if (j && j.ok && j.token) {
        chrome.storage.local.set({
          cc_ext_token: j.token,
          cc_ext_email: j.email || msg.email || ""
        }, function () { sendResponse(j); });
      } else {
        sendResponse(j || { ok: false });
      }
    });
    return true; /* async sendResponse */
  }
  if (msg && msg.type === "cc-ext-handoff") {
    extApi({ action: "handoff", next: msg.next || "/piggybank/" }, function (j) {
      if (j && j.error === "bad_token") clearExtSession();
      sendResponse(j || { ok: false });
    });
    return true;
  }
  if (msg && msg.type === "cc-ext-logout") {
    extApi({ action: "logout" }, function () {
      clearExtSession();
      sendResponse({ ok: true });
    });
    return true;
  }
  if (msg && msg.type === "cc-autotest-done" && msg.ok && msg.couponId) {
    /* A code Penny tested really worked: log it to the member's web
     * piggybank too (no-op when signed out - the API replies 401 and
     * the local savings ledger below remains the only record). */
    extApi({ action: "event", type: "useful", coupon_id: msg.couponId },
           function () {});
  }
  if (msg && msg.type === "cc-open-popup") {
    var opened = false;
    var openStorePage = function () {
      if (opened) return;
      opened = true;
      chrome.tabs.create({
        url: (typeof CC_SITE_URL !== "undefined" ? CC_SITE_URL : "") +
          "/stores/" + (msg.slug || "") + "/"
      });
    };
    try {
      var p = chrome.action.openPopup();
      if (p && typeof p.then === "function") {
        p.then(function () { opened = true; }, openStorePage);
      } else {
        opened = true; /* non-promise environment: assume it worked */
      }
    } catch (e) { openStorePage(); }
    sendResponse({ ok: true });
  }
});
