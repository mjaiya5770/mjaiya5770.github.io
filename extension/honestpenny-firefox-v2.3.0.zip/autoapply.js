/* Honest Penny v2 — PennyAuto: automatic coupon testing at checkout.
 *
 * What it does (ONLY after the user explicitly clicks "Test my codes"):
 *  - Detects checkout/cart pages (URL pattern OR a visible promo field).
 *  - Finds the retailer's promo-code field (per-store overrides, else a
 *    generic heuristic that matches promo/coupon/discount/voucher inputs).
 *  - Tries each cached code one at a time: fills the field, clicks the
 *    retailer's own Apply button, waits, and reads the cart total.
 *  - Keeps the code that produced the lowest total and re-applies it.
 *  - Records the savings so the popup can show a lifetime total.
 *
 * What it NEVER does:
 *  - Never runs without an explicit user click. No auto-run on page load.
 *  - Never submits an order, never touches payment/shipping/login fields.
 *  - Never sends any data anywhere. Everything stays in the page.
 *
 * Exposes window.PennyAuto = { isCheckoutPage, findPromoField, testCodes }.
 * Remote per-store tuning lives in data/extension-config.json (fetched by
 * the background worker into chrome.storage.local as cc_ext_config), so
 * retailers can be tuned without shipping a new extension version.
 */
/* global CC_EXT_CONFIG */
(function () {
  "use strict";

  var DEFAULTS = {
    checkout_url_pattern: "checkout|check-out|/cart|/basket|/bag|/payment|order-review|order_summary|shipping",
    promo_attrs: ["promo", "coupon", "discount", "voucher", "promocode", "couponcode", "discountcode", "giftcard", "gift-card", "rewards-code"],
    exclude_attrs: ["email", "e-mail", "password", "passwd", "search", "username", "user-name", "phone", "tel", "address", "login", "signin", "sign-in", "card-number", "cvv", "zip"],
    apply_button_text: "apply|redeem|^add$|use code",
    total_labels: ["order total", "grand total", "estimated total", "total amount", "amount due", "order summary", "cart total", "subtotal"],
    error_text: "invalid|expired|not valid|does not apply|doesn't apply|cannot be applied|can't be applied|already applied|not recognized|incorrect|please enter|try again|not eligible|minimum",
    max_codes: 12,
    wait_after_apply_ms: 3200,
    delay_between_codes_ms: 2200
  };

  function cfg() {
    var remote = (typeof CC_EXT_CONFIG !== "undefined" && CC_EXT_CONFIG) || {};
    var d = {};
    var k;
    for (k in DEFAULTS) d[k] = DEFAULTS[k];
    if (remote.defaults) for (k in remote.defaults) d[k] = remote.defaults[k];
    return { d: d, stores: remote.stores || {} };
  }

  function storeCfg(slug) {
    var c = cfg();
    return c.stores[slug] || {};
  }

  /* ---------------- checkout detection ---------------- */

  function isCheckoutPage(slug) {
    var c = cfg();
    var sc = storeCfg(slug);
    var pattern = sc.checkout_url || c.d.checkout_url_pattern;
    try {
      if (new RegExp(pattern, "i").test(location.href)) return true;
    } catch (e) { /* bad pattern: fall through to field sniffing */ }
    return !!findPromoField(slug);
  }

  /* ---------------- element helpers ---------------- */

  function visible(el) {
    if (!el || el.disabled) return false;
    if (el.type === "hidden") return false;
    try {
      var r = el.getBoundingClientRect();
      if (r.width < 4 || r.height < 4) return false;
    } catch (e) { return false; }
    var style;
    try { style = window.getComputedStyle(el); } catch (e) { return true; }
    return style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
  }

  function attrBlob(el) {
    return ((el.id || "") + " " + (el.name || "") + " " + (el.placeholder || "") + " " +
      (el.getAttribute("aria-label") || "") + " " + (el.className || "")).toLowerCase();
  }

  function trySelectors(selectors, safeFn) {
    for (var i = 0; i < selectors.length; i++) {
      var els;
      try { els = document.querySelectorAll(selectors[i]); } catch (e) { continue; }
      for (var j = 0; j < els.length; j++) {
        if (visible(els[j]) && (!safeFn || safeFn(els[j]))) return els[j];
      }
    }
    return null;
  }

  /* A promo field is only safe when its attributes carry none of the
     sensitive exclusions and it does not live in a form that also asks
     for a password. Configured per-store selectors get NO bypass. */
  function fieldSafe(el) {
    if (!el || el.type === "password") return false;
    var c = cfg().d;
    var blob = attrBlob(el);
    for (var k = 0; k < c.exclude_attrs.length; k++) {
      if (blob.indexOf(c.exclude_attrs[k]) !== -1) return false;
    }
    var form = el.form;
    if (form && form.querySelector('input[type="password"]')) return false;
    return true;
  }

  var DANGER_BUTTON_TEXT = "place order|place your order|checkout|pay now|complete (order|purchase|checkout)|submit (order|payment)|buy now|confirm (order|purchase|payment|checkout)|pay \$|proceed to (checkout|payment)";

  /* An apply control is only safe when it does not read like an order
     submission. Configured per-store selectors get NO bypass. */
  function buttonSafe(el) {
    var t = (el.textContent || el.value || "").trim().toLowerCase();
    if (!t) return true;
    try { return !new RegExp(DANGER_BUTTON_TEXT, "i").test(t); } catch (e) { return false; }
  }

  /* ---------------- promo field ---------------- */

  function findPromoField(slug) {
    var sc = storeCfg(slug);
    if (sc.promo_selectors && sc.promo_selectors.length) {
      var hit = trySelectors(sc.promo_selectors, fieldSafe);
      if (hit) return hit;
    }
    var c = cfg().d;
    var inputs = document.querySelectorAll('input[type="text"], input[type="search"], input:not([type])');
    for (var i = 0; i < inputs.length; i++) {
      var el = inputs[i];
      if (!visible(el)) continue;
      var blob = attrBlob(el);
      var okAttr = false, k;
      for (k = 0; k < c.promo_attrs.length; k++) {
        if (blob.indexOf(c.promo_attrs[k]) !== -1) { okAttr = true; break; }
      }
      if (!okAttr) continue;
      var bad = false;
      for (k = 0; k < c.exclude_attrs.length; k++) {
        if (blob.indexOf(c.exclude_attrs[k]) !== -1) { bad = true; break; }
      }
      if (bad) continue;
      /* Skip fields inside a login form (a form containing a password input). */
      var form = el.form;
      if (form && form.querySelector('input[type="password"]')) continue;
      return el;
    }
    return null;
  }

  /* ---------------- apply button ---------------- */

  function buttonTextMatch(el, pattern) {
    var t = (el.textContent || el.value || "").trim().toLowerCase();
    if (!t) return false;
    try { return new RegExp(pattern, "i").test(t); } catch (e) { return false; }
  }

  function findApplyButton(field, slug) {
    var sc = storeCfg(slug);
    var c = cfg().d;
    if (sc.apply_selectors && sc.apply_selectors.length) {
      var hit = trySelectors(sc.apply_selectors, function (el) {
        if (!buttonSafe(el)) return false;
        /* A submit-type control additionally has to READ as a coupon
           control: a bare denylist is not a safety boundary for the
           button that could send the order. */
        if ((el.type || "").toLowerCase() === "submit" &&
            !buttonTextMatch(el, c.apply_button_text)) return false;
        return true;
      });
      if (hit) return hit;
    }
    var scope = field.form || field.parentElement;
    if (scope) {
      var btns = scope.querySelectorAll('button, input[type="submit"], input[type="button"], [role="button"]');
      for (var i = 0; i < btns.length; i++) {
        if (visible(btns[i]) && buttonSafe(btns[i]) && buttonTextMatch(btns[i], c.apply_button_text)) return btns[i];
      }
    }
    /* Widen: walk up a few levels looking for an apply-ish button. */
    var node = field.parentElement, depth = 0;
    while (node && depth < 4) {
      var cand = node.querySelectorAll('button, input[type="submit"], input[type="button"]');
      for (var j = 0; j < cand.length; j++) {
        if (visible(cand[j]) && buttonSafe(cand[j]) && buttonTextMatch(cand[j], c.apply_button_text)) return cand[j];
      }
      node = node.parentElement; depth++;
    }
    return null;
  }

  /* ---------------- cart total ---------------- */

  function parseMoney(text) {
    var m = /\$\s?([\d,]+\.\d{2})/.exec(text || "");
    if (!m) return null;
    var v = parseFloat(m[1].replace(/,/g, ""));
    return isFinite(v) ? v : null;
  }

  /* Cache the element that held the total: totals update in place on most
     checkout pages, so subsequent polls can skip the full DOM scan. */
  var totalElCache = null;

  function leafVisible(el) {
    try {
      if (!el.getClientRects || !el.getClientRects().length) return false;
      var st = window.getComputedStyle(el);
      return st.display !== "none" && st.visibility !== "hidden";
    } catch (e) { return false; }
  }

  function readTotal(slug) {
    var sc = storeCfg(slug);
    if (sc.total_selectors && sc.total_selectors.length) {
      var hit = trySelectors(sc.total_selectors);
      if (hit) {
        var v0 = parseMoney(hit.textContent);
        if (v0 !== null) { totalElCache = hit; return v0; }
      }
    }
    if (totalElCache && totalElCache.isConnected && leafVisible(totalElCache)) {
      var vc = parseMoney(totalElCache.textContent);
      if (vc !== null) return vc;
      totalElCache = null;
    }
    var c = cfg().d;
    var best = null, bestScore = -1, bestEl = null, bestLen = Infinity;
    var all = document.querySelectorAll("body *");
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      /* Never read money out of script/style/template source. */
      var tag = el.tagName;
      if (tag === "SCRIPT" || tag === "STYLE" || tag === "NOSCRIPT" || tag === "TEMPLATE") continue;
      if (el.children.length > 0) continue; /* leaf nodes only */
      if (!leafVisible(el)) continue; /* hidden totals are stale totals */
      var text = (el.textContent || "").trim();
      if (text.length > 40) continue;
      var money = parseMoney(text);
      if (money === null) continue;
      var score = 0;
      var node = el, depth = 0, ctx = "";
      while (node && depth < 4) {
        ctx += " " + ((node.textContent || "").slice(0, 120)).toLowerCase();
        node = node.parentElement; depth++;
      }
      for (var k = 0; k < c.total_labels.length; k++) {
        if (ctx.indexOf(c.total_labels[k]) !== -1) { score += 10 - k; break; }
      }
      score -= depth;
      /* Tie-break: prefer the shorter (more specific) money text, e.g. a
         bare "$80.00" total over a static "Subtotal (2 items): $100.00" line
         that happens to score the same. */
      if (score > bestScore || (score === bestScore && text.length < bestLen)) {
        bestScore = score; best = money; bestEl = el; bestLen = text.length;
      }
    }
    if (bestEl) totalElCache = bestEl;
    return best;
  }

  /* Visible text under a root, skipping script/style/template source: an
     inline <script> can literally contain the words "invalid"/"expired"
     (e.g. its own error strings), which must never count as the page
     showing the shopper an error. Same for money scanning. */
  function visibleText(root) {
    var parts = [];
    var walker;
    try {
      walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode: function (n) {
          var p = n.parentElement;
          if (!p) return NodeFilter.FILTER_REJECT;
          var tag = p.tagName;
          if (tag === "SCRIPT" || tag === "STYLE" || tag === "NOSCRIPT" ||
              tag === "TEMPLATE" || tag === "TEXTAREA") return NodeFilter.FILTER_REJECT;
          try {
            var st = window.getComputedStyle(p);
            if (st.display === "none" || st.visibility === "hidden") return NodeFilter.FILTER_REJECT;
          } catch (e) {}
          return NodeFilter.FILTER_ACCEPT;
        }
      });
    } catch (e) { return (root.textContent || ""); }
    var n;
    while ((n = walker.nextNode())) parts.push(n.nodeValue);
    return parts.join(" ");
  }

  function errorText(field) {
    var scope = field.form || field.parentElement;
    var root = scope;
    var node = field.parentElement, depth = 0;
    while (node && depth < 3) { root = node; node = node.parentElement; depth++; }
    try { return visibleText(root || document.body).toLowerCase(); } catch (e) { return ""; }
  }

  /* An error counts only when the visible error text CHANGED with this
     attempt: generic words ("minimum", "expired") sitting statically
     in the page copy must not condemn a code. */
  function pageShowsError(field, preText) {
    var c = cfg().d;
    var blob = errorText(field);
    if (blob === preText) return false;
    try { return new RegExp(c.error_text, "i").test(blob); } catch (e) { return false; }
  }

  /* ---------------- value setting (framework-safe) ---------------- */

  function setFieldValue(field, value) {
    try { field.focus(); } catch (e) {}
    try {
      var proto = field.tagName === "TEXTAREA"
        ? window.HTMLTextAreaElement.prototype
        : window.HTMLInputElement.prototype;
      var setter = Object.getOwnPropertyDescriptor(proto, "value").set;
      setter.call(field, value);
    } catch (e) {
      try { field.value = value; } catch (e2) {}
    }
    field.dispatchEvent(new Event("input", { bubbles: true }));
    field.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function sleep(ms) {
    return new Promise(function (res) { setTimeout(res, ms); });
  }

  /* ---------------- the test loop ---------------- */

  function testCodes(slug, codes, hooks) {
    hooks = hooks || {};
    var c = cfg().d;
    var sc = storeCfg(slug);
    var maxCodes = sc.max_codes || c.max_codes;
    /* The user's own options-page choice wins over remote config. */
    try {
      if (typeof CC_USER_MAX_CODES !== "undefined" && CC_USER_MAX_CODES > 0) {
        maxCodes = CC_USER_MAX_CODES;
      }
    } catch (e) {}
    var waitMs = sc.wait_after_apply_ms || c.wait_after_apply_ms;
    var gapMs = sc.delay_between_codes_ms || c.delay_between_codes_ms;

    var cancelled = false;
    var navigated = false;
    window.addEventListener("pagehide", function () { navigated = true; }, { once: true });

    function progress(info) {
      try { if (hooks.onProgress) hooks.onProgress(info); } catch (e) {}
    }
    function done(result) {
      try { if (hooks.onDone) hooks.onDone(result); } catch (e) {}
    }

    function run() {
      var field = findPromoField(slug);
      if (!field) {
        done({ ok: false, reason: "no-field", tried: 0 });
        return;
      }
      var applyBtn = findApplyButton(field, slug);
      var startTotal = readTotal(slug);
      /* Whatever discount the shopper already had in the box is theirs:
         if none of our codes beats it, it goes back (verified) - testing
         must never leave a shopper worse off than before Penny ran. */
      var originalCode = (field.value || "").trim();
      var queue = codes.filter(function (x) { return x && x.code; }).slice(0, maxCodes);

      if (!queue.length) {
        done({ ok: false, reason: "no-codes", tried: 0 });
        return;
      }

      var best = null; /* {code, total} */
      var i = 0;

      function next() {
        if (cancelled) { finish({ ok: false, reason: "cancelled", tried: i }); return; }
        if (navigated) { finish({ ok: false, reason: "navigated", tried: i }); return; }
        if (i >= queue.length) { finish(null); return; }
        var coupon = queue[i];
        var preErrText = errorText(field);
        progress({ done: i, total: queue.length, code: coupon.code, status: "testing" });
        if (!applyBtn || !visible(applyBtn)) {
          /* No positively identified, safe Apply control: stop rather
             than guess. A synthetic Enter can submit the whole checkout
             on some retailers - never worth the risk. */
          finish({ ok: false, reason: "no-apply-button", tried: i });
          return;
        }
        try {
          setFieldValue(field, "");
          setFieldValue(field, coupon.code);
          applyBtn.click();
        } catch (e) { /* fall through to wait */ }

        var polls = 0, maxPolls = Math.ceil(waitMs / 400);
        var baseline = (best && best.total !== null) ? best.total : startTotal;
        var settleVal = null, settleCount = 0;
        (function poll() {
          if (cancelled || navigated) { finish({ ok: false, reason: cancelled ? "cancelled" : "navigated", tried: i + 1 }); return; }
          var total = readTotal(slug);
          /* A total is only attributable once it SETTLES (two equal
             consecutive reads): a slow retailer response for code A must
             not be credited to code B just because it landed during B's
             window. */
          if (total !== null && settleVal !== null && Math.abs(total - settleVal) < 0.005) {
            settleCount++;
          } else {
            settleVal = total; settleCount = total !== null ? 1 : 0;
          }
          var settled = settleCount >= 2 ? settleVal : null;
          var err = pageShowsError(field, preErrText);
          var improved = (settled !== null && baseline !== null && settled < baseline - 0.005);
          if (improved || err || ++polls >= maxPolls) {
            total = settled !== null ? settled : total;
            if (improved && (best === null || total < best.total)) {
              best = { code: coupon.code, total: total, title: coupon.title, id: coupon.id || "" };
            }
            progress({ done: i + 1, total: queue.length, code: coupon.code, status: improved ? "worked" : (err ? "rejected" : "no-change") });
            i++;
            setTimeout(next, gapMs);
          } else {
            setTimeout(poll, 400);
          }
        })();
      }

      function restoreOriginal(cb) {
        if (!originalCode) { try { setFieldValue(field, ""); } catch (e) {} cb(false); return; }
        try {
          setFieldValue(field, "");
          setFieldValue(field, originalCode);
          if (applyBtn && visible(applyBtn)) applyBtn.click();
        } catch (e) { cb(false); return; }
        var waited = 0, match = 0;
        (function pollRestore() {
          var t = readTotal(slug);
          if (t !== null && startTotal !== null && Math.abs(t - startTotal) < 0.005) {
            match++;
            if (match >= 2) { cb(true); return; }
          } else { match = 0; }
          waited += 400;
          if (waited >= waitMs) { cb(false); return; }
          setTimeout(pollRestore, 400);
        })();
      }

      function finish(early) {
        if (early) {
          if (early.reason === "cancelled") {
            /* Leave the cart in its best known state: the winning code
               so far goes back in the box; without one, the shopper's
               own pre-existing code goes back instead. */
            try {
              if (best) {
                setFieldValue(field, "");
                setFieldValue(field, best.code);
                if (applyBtn && visible(applyBtn)) applyBtn.click();
                early.kept = best.code;
              } else if (originalCode) {
                restoreOriginal(function (restored) {
                  early.restoredOriginal = restored;
                  if (!restored) early.originalCode = originalCode;
                  done(early);
                });
                return;
              } else {
                setFieldValue(field, "");
              }
            } catch (e) {}
          }
          done(early);
          return;
        }
        if (best) {
          /* Re-apply the winner so the shopper keeps the best price,
             then VERIFY the best total actually came back before
             crediting any savings. */
          try {
            setFieldValue(field, "");
            setFieldValue(field, best.code);
            if (applyBtn && visible(applyBtn)) applyBtn.click();
          } catch (e) {}
          var waited = 0, match = 0;
          (function verify() {
            if (cancelled) {
              done({ ok: false, reason: "cancelled", tried: queue.length, kept: best.code });
              return;
            }
            var finalTotal = readTotal(slug);
            /* The winner counts as restored only when its total is seen
               SETTLED (two equal consecutive reads) at exactly the best
               total. A merely-lower total on timeout belongs to some
               other state of the cart - never credit it to this code. */
            if (finalTotal !== null && Math.abs(finalTotal - best.total) < 0.005) {
              match++;
            } else { match = 0; }
            if (match >= 2) {
              var saved = startTotal !== null ? startTotal - best.total : 0;
              if (saved > 0.005) {
                recordSavings(slug, best.code, saved);
                done({ ok: true, saved: saved, code: best.code, title: best.title, id: best.id || "", tried: queue.length, startTotal: startTotal, finalTotal: best.total });
              } else {
                done({ ok: false, reason: "winner-lost", tried: queue.length });
              }
              return;
            }
            if (waited >= waitMs) {
              done({ ok: false, reason: "winner-lost", tried: queue.length });
              return;
            }
            waited += 400;
            setTimeout(verify, 400);
          })();
        } else if (originalCode) {
          restoreOriginal(function (restored) {
            done({ ok: false, reason: "none-worked", tried: queue.length,
                   restoredOriginal: restored,
                   originalCode: restored ? "" : originalCode });
          });
        } else {
          try { setFieldValue(field, ""); } catch (e) {}
          done({ ok: false, reason: "none-worked", tried: queue.length });
        }
      }

      next();
    }

    /* Kick off async so the caller can wire up listeners first. */
    setTimeout(run, 50);

    return { cancel: function () { cancelled = true; } };
  }

  function recordSavings(slug, code, amount) {
    if (!(amount > 0)) return;
    var eventId = "sv-" + Date.now() + "-" + Math.random().toString(36).slice(2, 10);
    try {
      chrome.runtime.sendMessage(
        { type: "cc-record-savings", amount: amount, code: code, store: slug, eventId: eventId },
        function () { void chrome.runtime.lastError; }
      );
    } catch (e) {}
  }

  window.PennyAuto = {
    isCheckoutPage: isCheckoutPage,
    findPromoField: findPromoField,
    isSafeField: fieldSafe,
    testCodes: testCodes,
    readTotal: readTotal
  };
})();
