/* Honest Penny welcome page: the "Start saving" button just closes the
 * tab. Kept in a packaged file because MV3 extension pages forbid
 * inline scripts (the handler silently never ran when inline). */
document.getElementById("welcome-go").addEventListener("click", function (e) {
  e.preventDefault();
  window.close();
});
