/* CouponCove - Cute Coupon Finder: content script.
 *
 * Runs on supported retailer domains (matches generated at build time).
 *  - Shows a cute Penny slide-in (bottom-left, dismissible, once per domain
 *    per day) when the store has cached coupons.
 *  - Listens for {type:"cc-apply-code", code} from the popup: finds the
 *    retailer's promo-code field, fills it, highlights it, and shows a toast.
 *    NEVER auto-submits anything.
 *
 * No tracking, no analytics. (cc-config.js is baked in at package time.)
 */

/* global CC_STORES */
(function () {
  "use strict";

  function storeForHost(host) {
    host = (host || "").toLowerCase();
    for (var i = 0; i < (CC_STORES || []).length; i++) {
      var d = CC_STORES[i].domain;
      if (host === d || host.slice(-d.length - 1) === "." + d) return CC_STORES[i];
    }
    return null;
  }

  var hit = storeForHost(location.hostname);
  if (!hit) return;

  /* ---------------- Penny slide-in ---------------- */
  var PENNY_SVG =
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="54" height="54" aria-hidden="true">' +
    '<ellipse cx="64" cy="70" rx="45" ry="36" fill="#FF8A7A"/>' +
    '<polygon points="40,46 30,22 55,35" fill="#FF8A7A"/>' +
    '<polygon points="88,46 98,22 73,35" fill="#FF8A7A"/>' +
    '<ellipse cx="64" cy="92" rx="27" ry="20" fill="#FFF3DC"/>' +
    '<rect x="50" y="30" width="28" height="7" rx="3.5" fill="#4A3728"/>' +
    '<path d="M42,60 q8,-9 16,0" fill="none" stroke="#4A3728" stroke-width="4.5" stroke-linecap="round"/>' +
    '<path d="M70,60 q8,-9 16,0" fill="none" stroke="#4A3728" stroke-width="4.5" stroke-linecap="round"/>' +
    '<ellipse cx="33" cy="72" rx="8" ry="5.5" fill="#FFB59E" opacity="0.8"/>' +
    '<ellipse cx="95" cy="72" rx="8" ry="5.5" fill="#FFB59E" opacity="0.8"/>' +
    '<ellipse cx="64" cy="76" rx="14" ry="11" fill="#F2736A"/>' +
    '<ellipse cx="58" cy="76" rx="3" ry="4.5" fill="#4A3728"/>' +
    '<ellipse cx="70" cy="76" rx="3" ry="4.5" fill="#4A3728"/>' +
    '<path d="M56,90 q8,7 16,0" fill="none" stroke="#4A3728" stroke-width="4" stroke-linecap="round"/>' +
    "</svg>";

  function todayKey() {
    var d = new Date();
    return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate();
  }

  function maybeSlideIn() {
    var dismissKey = "cc_dismiss_" + hit.slug + "_" + todayKey();
    chrome.storage.local.get(["cc_coupons", dismissKey], function (res) {
      if (res[dismissKey]) return;
      var coupons = res.cc_coupons || [];
      var mine = coupons.filter(function (c) { return c.store_slug === hit.slug; });
      if (!mine.length) return;

      var box = document.createElement("div");
      box.id = "cc-penny-slide";
      box.setAttribute("role", "dialog");
      box.setAttribute("aria-label", "CouponCove deals for " + hit.name);
      box.style.cssText =
        "position:fixed;left:16px;bottom:16px;z-index:2147483647;" +
        "display:flex;align-items:center;gap:12px;max-width:min(340px,calc(100vw - 32px));" +
        "background:#FFF8F0;border:2px solid #FF7B6B;border-radius:22px;" +
        "box-shadow:0 12px 32px rgba(74,55,40,.25);padding:12px 14px;" +
        "font-family:ui-rounded,'Arial Rounded MT Bold','Helvetica Rounded',system-ui,sans-serif;" +
        "color:#4A3728;transform:translateY(24px);opacity:0;" +
        "transition:transform .35s ease,opacity .35s ease;";
      box.innerHTML =
        '<div style="flex:none">' + PENNY_SVG + "</div>" +
        '<div style="flex:1;min-width:0">' +
        '<div style="font-weight:800;font-size:14px;line-height:1.3">Penny found ' +
        mine.length + " deal" + (mine.length > 1 ? "s" : "") + " for " +
        escapeHtml(hit.name) + "!</div>" +
        '<button id="cc-penny-open" style="margin-top:8px;border:0;cursor:pointer;' +
        "background:#FF7B6B;color:#4A3728;font-weight:800;font-size:13px;" +
        'padding:8px 16px;border-radius:999px;font-family:inherit">Show my deals</button>' +
        "</div>" +
        '<button id="cc-penny-x" aria-label="Dismiss" style="flex:none;align-self:flex-start;' +
        "border:0;background:none;cursor:pointer;font-size:16px;color:#8A6A55;line-height:1;" +
        'font-family:inherit">\u00d7</button>';

      document.documentElement.appendChild(box);
      requestAnimationFrame(function () {
        requestAnimationFrame(function () {
          box.style.transform = "translateY(0)";
          box.style.opacity = "1";
        });
      });

      var done = false;
      function dismiss(persist) {
        if (done) return; done = true;
        if (persist) {
          var o = {}; o[dismissKey] = true;
          chrome.storage.local.set(o);
        }
        box.style.transform = "translateY(24px)";
        box.style.opacity = "0";
        setTimeout(function () { box.remove(); }, 400);
      }
      box.querySelector("#cc-penny-x").addEventListener("click", function () { dismiss(true); });
      box.querySelector("#cc-penny-open").addEventListener("click", function () {
        dismiss(false);
        chrome.runtime.sendMessage({ type: "cc-open-popup", slug: hit.slug });
      });
    });
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", maybeSlideIn);
  } else {
    maybeSlideIn();
  }

  /* ---------------- Apply-code helper ---------------- */
  var PROMO_SELECTORS = [
    'input[name*="promo" i]', 'input[name*="coupon" i]', 'input[name*="discount" i]',
    'input[name*="voucher" i]', 'input[id*="promo" i]', 'input[id*="coupon" i]',
    'input[id*="discount" i]', "#promo-code", "#coupon-code", "#promocode",
    ".promo-code-input", ".coupon-code-input",
    'input[placeholder*="promo" i]', 'input[placeholder*="coupon" i]',
    'input[placeholder*="discount" i]', 'input[aria-label*="promo" i]',
    'input[aria-label*="coupon" i]'
  ];

  function findPromoField() {
    for (var i = 0; i < PROMO_SELECTORS.length; i++) {
      var el = document.querySelector(PROMO_SELECTORS[i]);
      if (el && el.offsetParent !== null && !el.disabled && el.type !== "hidden") return el;
    }
    return null;
  }

  function pennyToast(msg) {
    var t = document.createElement("div");
    t.setAttribute("role", "status");
    t.style.cssText =
      "position:fixed;left:50%;bottom:28px;transform:translateX(-50%) translateY(16px);" +
      "z-index:2147483647;background:#4A3728;color:#FFF8F0;font-weight:700;font-size:14px;" +
      "padding:12px 22px;border-radius:999px;box-shadow:0 8px 24px rgba(0,0,0,.25);" +
      "font-family:ui-rounded,'Arial Rounded MT Bold',system-ui,sans-serif;" +
      "transition:transform .3s ease,opacity .3s ease;opacity:0;max-width:92vw;text-align:center;";
    t.textContent = msg;
    document.documentElement.appendChild(t);
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        t.style.transform = "translateX(-50%) translateY(0)";
        t.style.opacity = "1";
      });
    });
    setTimeout(function () {
      t.style.opacity = "0";
      setTimeout(function () { t.remove(); }, 400);
    }, 3200);
  }

  chrome.runtime.onMessage.addListener(function (msg) {
    if (!msg || msg.type !== "cc-apply-code" || !msg.code) return;
    var field = findPromoField();
    if (!field) {
      pennyToast("Penny couldn't find the promo box on this page \u2014 paste it at checkout!");
      return;
    }
    field.focus();
    /* Set value through the native setter so framework bindings notice. */
    var proto = field.tagName === "TEXTAREA"
      ? window.HTMLTextAreaElement.prototype
      : window.HTMLInputElement.prototype;
    var setter = Object.getOwnPropertyDescriptor(proto, "value").set;
    setter.call(field, msg.code);
    field.dispatchEvent(new Event("input", { bubbles: true }));
    field.dispatchEvent(new Event("change", { bubbles: true }));
    field.style.outline = "3px solid #FF7B6B";
    field.style.outlineOffset = "2px";
    field.style.borderRadius = "8px";
    try { field.scrollIntoView({ behavior: "smooth", block: "center" }); } catch (e) {}
    pennyToast("Penny pasted your code \u2014 hit Apply! \uD83D\uDC37");
  });
})();
